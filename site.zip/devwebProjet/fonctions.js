function myFunction() {
    alert("Message");
  }
  
  function myOtherFunction() {
    console.log("Mouse out of image");
  }

let monBouton = document.getElementById("monBouton");
monBouton.addEventListener("mouseover", afficherMessage);
